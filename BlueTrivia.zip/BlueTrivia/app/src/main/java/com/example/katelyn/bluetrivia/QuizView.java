package com.example.katelyn.bluetrivia;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class QuizView extends AppCompatActivity
{
    private static final String KEY_INDEX = "index";

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState)
    {
        super .onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt(KEY_INDEX, mCurrentIndex);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_view);

        mQuestionTV = (TextView)findViewById(R.id.question_textView);

        if(savedInstanceState != null)
        {
            mCurrentIndex = savedInstanceState.getInt(KEY_INDEX);
            mQuestionTV.setText(mQuestionBank[mCurrentIndex]);
        }
        else
        {
           // mQuestionTV.setText(R.string.question_text1);
        }

        mAnswerTV = (TextView) findViewById(R.id.answer_textView);
        mTrueButton = (Button) findViewById(R.id.true_button);
        mFalseButton = (Button) findViewById(R.id.false_button);
        mNextButton = (Button) findViewById(R.id.next_button);
    }

    private Button mTrueButton;
    private Button mFalseButton;
    private Button mNextButton;

        //mTrueButton.setOnClickListener(new View.OnClickListener());

        //mFalseButton.setOnClickListener(new View.OnClickListener());

        //mNextButton.setOnClickListener(new View.OnClickListener());

    private TextView mQuestionTV;
    private TextView mAnswerTV;
    private int mCurrentIndex = 0;
    private int [] mQuestionBank = new int []
            {

            };
    private boolean[] mAnswerBank = new boolean[]{};
}
